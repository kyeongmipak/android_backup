package com.jsplec.base;

public class BeanPurchaser {
	// field
	private String userid;
	private String name;
	private String tel;
	private String address;
	
	// constructor
	public BeanPurchaser() {
		// TODO Auto-generated constructor stub
	}

	
	// method
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	

	
}
