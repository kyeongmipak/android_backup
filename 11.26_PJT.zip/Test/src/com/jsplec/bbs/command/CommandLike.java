package com.jsplec.bbs.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CommandLike implements Command {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {

		int boardNum = Integer.parseInt(request.getParameter("boardNum"));
		
		
		
	}

}
