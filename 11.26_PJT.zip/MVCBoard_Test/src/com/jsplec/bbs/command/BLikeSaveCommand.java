package com.jsplec.bbs.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jsplec.bbs.dao.BDao;
import com.jsplec.bbs.dto.BDto;
import com.mysql.cj.Session;

public class BLikeSaveCommand implements BCommand {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
	}

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response, HttpSession session) {

		String saveTitle = request.getParameter("saveTitle");
		String bSeq = (String)session.getAttribute("BIDLIKE");
		String bName = "장비";
		
		BDao dao = new BDao();
		dao.likeClick(bSeq, bName, saveTitle);
		
	}

}
