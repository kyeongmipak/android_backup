CREATE DATABASE  IF NOT EXISTS `room` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `room`;
-- MySQL dump 10.13  Distrib 8.0.17, for macos10.14 (x86_64)
--
-- Host: localhost    Database: room
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `boardid` int(11) NOT NULL AUTO_INCREMENT,
  `boardtitle` varchar(45) DEFAULT NULL,
  `boardcontent` text,
  `boardinsertdate` date DEFAULT NULL,
  `userinfo_userid` varchar(45) NOT NULL,
  PRIMARY KEY (`boardid`,`userinfo_userid`),
  KEY `fk_board_userinfo1_idx` (`userinfo_userid`),
  CONSTRAINT `fk_board_userinfo1` FOREIGN KEY (`userinfo_userid`) REFERENCES `userinfo` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (2,'dddd','dddd난 돌아갈래\r\n','2020-12-06','admin');
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book` (
  `bookid` int(11) NOT NULL AUTO_INCREMENT,
  `room_roomid` int(11) NOT NULL,
  `userinfo_userid` varchar(45) NOT NULL,
  `bookcheckindate` date DEFAULT NULL,
  `bookcheckoutdate` date DEFAULT NULL,
  `bookcapa` int(11) DEFAULT NULL,
  `bookpricetotal` int(11) DEFAULT NULL,
  PRIMARY KEY (`bookid`,`room_roomid`,`userinfo_userid`),
  KEY `fk_book_room_idx` (`room_roomid`),
  KEY `fk_book_userinfo1_idx` (`userinfo_userid`),
  CONSTRAINT `fk_book_room` FOREIGN KEY (`room_roomid`) REFERENCES `room` (`roomid`),
  CONSTRAINT `fk_book_userinfo1` FOREIGN KEY (`userinfo_userid`) REFERENCES `userinfo` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (2,25,'qkr@naver.com','2020-12-09','2020-12-13',2,NULL),(3,25,'qkr@naver.com','2020-12-30','2020-12-31',1,763256),(4,74,'qkr@naver.com',NULL,NULL,2,1255792),(5,25,'1@1.com','2020-12-14','2020-12-15',1,400000),(6,25,'godol811@naver.com','2020-12-18','2020-12-20',1,480000),(7,28,'chl@naver.com',NULL,NULL,1,191400),(8,23,'chl@naver.com',NULL,NULL,1,240000),(9,62,'chl@naver.com',NULL,NULL,1,480000),(10,86,'chl@naver.com',NULL,NULL,1,134414),(11,81,'chl@naver.com',NULL,NULL,1,143814),(12,24,'godol811@naver.com',NULL,NULL,1,3380000),(13,25,'godol811@naver.com',NULL,NULL,2,210000),(14,26,'godol811@naver.com',NULL,NULL,2,3135000),(15,54,'qkr@naver.com',NULL,NULL,1,NULL),(16,55,'qkr@naver.com',NULL,NULL,1,NULL),(17,28,'qkr@naver.com',NULL,NULL,1,NULL),(18,27,'qkr@naver.com',NULL,NULL,1,NULL),(19,72,'qkr@naver.com',NULL,NULL,1,NULL),(20,63,'qkr@naver.com',NULL,NULL,1,NULL),(21,81,'qkr@naver.com',NULL,NULL,1,NULL),(22,73,'godol811@naver.com',NULL,NULL,1,NULL),(23,63,'godol811@naver.com',NULL,NULL,1,NULL),(24,27,'godol811@naver.com',NULL,NULL,1,NULL),(25,58,'godol811@naver.com',NULL,NULL,3,NULL),(26,27,'godol811@naver.com',NULL,NULL,1,NULL),(27,27,'godol811@naver.com',NULL,NULL,1,NULL),(28,29,'dl@naver.com',NULL,NULL,1,NULL),(29,27,'dl@naver.com',NULL,NULL,2,NULL),(30,30,'dl@naver.com',NULL,NULL,1,NULL),(31,30,'dl@naver.com',NULL,NULL,1,NULL),(32,62,'dl@naver.com',NULL,NULL,1,NULL),(33,56,'godol811@naver.com',NULL,NULL,1,NULL),(34,57,'godol811@naver.com',NULL,NULL,1,NULL),(35,62,'rla@naver.com',NULL,NULL,1,NULL),(36,59,'rla@naver.com',NULL,NULL,1,NULL),(37,60,'rla@naver.com',NULL,NULL,1,NULL),(38,61,'rla@naver.com',NULL,NULL,1,NULL),(39,64,'rla@naver.com',NULL,NULL,1,NULL),(40,65,'rla@naver.com',NULL,NULL,1,NULL),(41,66,'rla@naver.com',NULL,NULL,1,NULL),(42,67,'rla@naver.com',NULL,NULL,1,NULL),(43,58,'123@naver.com',NULL,NULL,NULL,NULL),(44,54,'123@naver.com',NULL,NULL,NULL,NULL),(45,54,'qkr@naver.com',NULL,NULL,NULL,NULL),(46,54,'qqq@naver.com','2020-12-08','2020-12-10',2,194574);
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bucket`
--

DROP TABLE IF EXISTS `bucket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bucket` (
  `userinfo_userid` varchar(45) NOT NULL,
  `room_roomid` int(11) NOT NULL,
  `bucketno` int(11) NOT NULL,
  PRIMARY KEY (`userinfo_userid`,`room_roomid`,`bucketno`),
  KEY `fk_bucket_room1_idx` (`room_roomid`),
  CONSTRAINT `fk_bucket_room1` FOREIGN KEY (`room_roomid`) REFERENCES `room` (`roomid`),
  CONSTRAINT `fk_bucket_userinfo1` FOREIGN KEY (`userinfo_userid`) REFERENCES `userinfo` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bucket`
--

LOCK TABLES `bucket` WRITE;
/*!40000 ALTER TABLE `bucket` DISABLE KEYS */;
/*!40000 ALTER TABLE `bucket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message` (
  `messageid` int(11) NOT NULL AUTO_INCREMENT,
  `room_userid` varchar(45) DEFAULT NULL,
  `userinfo_userid` varchar(45) DEFAULT NULL,
  `messageContent` text,
  `messageinsertdate` datetime DEFAULT NULL,
  `book_bookid` int(11) DEFAULT NULL,
  PRIMARY KEY (`messageid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES (1,'qkr@naver.com','qkr@naver.com','erfjdkfjkd','2020-12-06 23:12:51',6),(2,'qkr@naver.com','qkr@naver.com','123124','2020-12-06 23:33:02',4),(3,'qkr@naver.com','qkr@naver.com','이밤 그날에 반딧불을\r\n','2020-12-06 23:37:16',3);
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `reviewid` int(11) NOT NULL AUTO_INCREMENT,
  `userinfo_userid` varchar(45) NOT NULL,
  `room_roomid` int(11) NOT NULL,
  `reviewtitle` varchar(45) DEFAULT NULL,
  `reviewcontent` text,
  `reviewrate` double DEFAULT NULL,
  `reviewdate` date DEFAULT NULL,
  `bookid` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`reviewid`,`userinfo_userid`,`room_roomid`),
  UNIQUE KEY `reviewid_UNIQUE` (`reviewid`),
  KEY `fk_review_userinfo1_idx` (`userinfo_userid`),
  KEY `fk_review_room1_idx` (`room_roomid`),
  CONSTRAINT `fk_review_room1` FOREIGN KEY (`room_roomid`) REFERENCES `room` (`roomid`),
  CONSTRAINT `fk_review_userinfo1` FOREIGN KEY (`userinfo_userid`) REFERENCES `userinfo` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (4,'qkr@naver.com',8,NULL,'11232131',4,'2020-12-07','2'),(5,'godol811@naver.com',8,NULL,'후져요',2.5,'2020-12-07','6'),(6,'chl@naver.com',28,NULL,'조금 더러운듯 해요 \r\n청소좀 자주 해주세요',2.5,'2020-12-08','7'),(7,'chl@naver.com',23,NULL,'조식이 맛있었어요 \r\n\r\n식당이 깔끔해서 좋았습니다.',4,'2020-12-08','8'),(8,'chl@naver.com',86,NULL,'안압지와 첨성대가 바로 보이는 이쁜 곳에 위치해서\r\n아침에 일어날때 아주 이뻤습니다 엄청 맘에 들어요\r\n',5,'2020-12-08','10'),(9,'godol811@naver.com',24,NULL,'신라호텔이름에 맞는 숙소입니다\r\n깔끔해서 맘에 들어요!',4.5,'2020-12-08','12'),(10,'godol811@naver.com',25,NULL,'바다가 잘보이는거 말곤 그닥 메리트가 없어보임\r\n\r\n창문 녹슬고 별로임',2.5,'2020-12-08','13'),(11,'godol811@naver.com',26,NULL,'카라반 호스텔 컨셉치곤 괜찮은듯 한데 \r\n모기장이 뜯어져있어 모기가 겁나 많네요\r\n여름엔 비추 ',3,'2020-12-08','14'),(12,'qkr@naver.com',54,NULL,'개후져요',2.5,'2020-12-08','15'),(13,'qkr@naver.com',55,NULL,'바다가 잘보여요',5,'2020-12-08','16'),(14,'qkr@naver.com',55,NULL,'',3.5,'2020-12-08','16'),(15,'godol811@naver.com',27,NULL,'sdfsdfdsf',3.5,'2020-12-08','27'),(16,'godol811@naver.com',27,NULL,'1111',2,'2020-12-08','27'),(17,'godol811@naver.com',27,NULL,'181818181818',2.5,'2020-12-08','24'),(18,'godol811@naver.com',27,NULL,'23',3,'2020-12-08','27'),(19,'godol811@naver.com',27,NULL,'1111',3,'2020-12-08','27'),(20,'godol811@naver.com',27,NULL,'d',1,'2020-12-08','27'),(21,'godol811@naver.com',27,NULL,'',1,'2020-12-08','27'),(22,'qkr@naver.com',63,NULL,'111',3,'2020-12-08','20'),(23,'godol811@naver.com',57,NULL,'1111',2.5,'2020-12-08','34'),(24,'godol811@naver.com',56,NULL,'배에 탄 느낌 그러나 후짐',3,'2020-12-08','33'),(25,'godol811@naver.com',27,NULL,'높은 마천루에 좋은 경관 잘보았습니다\r\n',3,'2020-12-08','27'),(26,'godol811@naver.com',58,NULL,'어디가 좋은지 모르겠어욧]\r\n',3,'2020-12-08','25'),(27,'godol811@naver.com',26,NULL,'호텔치고 싸네요\r\n',3,'2020-12-08','14'),(28,'rla@naver.com',62,NULL,'깔끔해요',3.5,'2020-12-08','35'),(29,'rla@naver.com',59,NULL,'웅장하니 이쁘네요',4,'2020-12-08','36'),(30,'rla@naver.com',60,NULL,'직원들이 엄청 깔끔하게 해줘서 맘에 들었습니다\r\n경치도 좋네요',5,'2020-12-08','37'),(31,'rla@naver.com',61,NULL,'산 한복판에 있어서 자연과 하나 될 수 있는 그런 기회를 가질 수 있어서 좋았습니다.',4.5,'2020-12-08','38'),(32,'rla@naver.com',64,NULL,'내부 풀이 엄청 이쁩니다 좋아요!',3.5,'2020-12-08','39'),(33,'rla@naver.com',65,NULL,'브루클린의 느낌이 물씬 풍기는 좋은 숙소네요',4,'2020-12-08','40'),(34,'rla@naver.com',66,NULL,'설악산의 정기를 느낄 수 있는 좋은 숙소입니다.',3,'2020-12-08','41'),(35,'rla@naver.com',67,NULL,'위생적이지 못했습니다',2.5,'2020-12-08','42'),(36,'qqq@naver.com',54,NULL,'정말 좋앗어요!',3.5,'2020-12-08','46');
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `roomid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(45) NOT NULL,
  `roomaddress` varchar(45) DEFAULT NULL,
  `roomaddressdetail` varchar(45) DEFAULT NULL,
  `roomcapa` int(11) DEFAULT NULL,
  `roomcheckin` time DEFAULT NULL,
  `roomcheckout` time DEFAULT NULL,
  `roomprice` int(11) DEFAULT NULL,
  `roomtitle` varchar(50) DEFAULT NULL,
  `roomcontent` text,
  `roomimage` varchar(45) DEFAULT NULL,
  `roomimagereal` varchar(45) DEFAULT NULL,
  `roomdeletedate` date DEFAULT NULL,
  `roomgpsx` double DEFAULT NULL,
  `roomgpsy` double DEFAULT NULL,
  PRIMARY KEY (`roomid`,`userid`),
  UNIQUE KEY `roomid_UNIQUE` (`roomid`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (8,'qkr@naver.com','',NULL,3,'13:00:00','10:00:00',20000,'방 제목','방 설명','123','tkwls','2020-12-08',34.287407387534515,-4.6652922794526255),(23,'rh@naver.com','부산광역시 해운대구 송정광어골로 67 (송정동)','',4,'14:00:00','11:00:00',120000,'Nudge567','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','1.jpeg','',NULL,35.1754461696363,129.196485040538),(24,'rla@naver.com','부산광역시 해운대구 해운대로570번길 46 (우동)','',2,'14:00:00','11:00:00',130000,'신라스테이 해운대호텔','코로나 방역을 항상 실시하고 있습니다','2.jpeg','',NULL,35.1598225444911,129.158751383824),(25,'qkr@naver.com','부산광역시 해운대구 달맞이길62번길 78 (중동)','12',5,'14:00:00','11:00:00',210000,'그랑빌','   호텔 사이트를 참조해주세요 :)좋아요~','3.jpeg','',NULL,35.1564285765789,129.175155538355),(26,'rh@naver.com','부산광역시 해운대구 송정중앙로6번길 180 (송정동)','',2,'14:00:00','11:00:00',95000,'해운대 카라반 호스텔',' 조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208152721201.peg','',NULL,35.1766785975804,129.196733641477),(27,'rla@naver.com','부산광역시 해운대구 송정광어골로 29 (송정동, 수정빌딩)','',3,'14:00:00','11:00:00',84000,'25th hostel',' 코로나 방역을 항상 실시하고 있습니다','5.jpeg','',NULL,35.1785867456159,129.197925324605),(28,'qkr@naver.com','부산광역시 해운대구 해운대해변로197번길 14 (우동, 조아텔)','',2,'14:00:00','11:00:00',95700,'캔버스블랙','  호텔 사이트를 참조해주세요 :)','6.jpeg','','2020-12-08',35.1593816135769,129.153004725317),(29,'rh@naver.com','부산광역시 해운대구 송정광어골 로82번길 16(송정동)','',1,'14:00:00','11:00:00',85000,'이너피스','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','7.jpeg','',NULL,35.1843254567509,129.200962943937),(30,'qkr@naver.com','부산광역시 해운대구 달맞이길62번가길 37, 우주모텔 (중동)','',2,'14:00:00','11:00:00',74300,'휘겔리 스위트','  호텔 사이트를 참조해주세요 :)','8.jpeg','','2020-12-08',35.1584699469446,129.171925092951),(31,'rla@naver.com','대구광역시 중구 경상감영길 193 (동문동)','',4,'14:00:00','11:00:00',230000,'리버틴호텔',' 코로나 방역을 항상 실시하고 있습니다','9.jpeg','',NULL,35.8721609688484,128.598018702989),(32,'rh@naver.com','대구광역시 중구 중앙대로77길 47 (장관동)','',6,'14:00:00','11:00:00',117967,'대구미드타운 호스텔','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','10.jpeg','',NULL,35.8683747890659,128.590858977718),(33,'dl@naver.com','대구광역시 중구 국채보상로 525 (하서동)',NULL,5,'15:00:00','10:00:00',117027,'영진아미고호텔(주)','','11.jpeg','',NULL,35.870618247601,128.592857829278),(34,'qkr@naver.com','대구광역시 중구 중앙대로81길 13 (동일동)','',3,'14:00:00','11:00:00',116087,'2월호텔 동성로점','  호텔 사이트를 참조해주세요 :)','12.jpeg','',NULL,35.8696087493229,128.592861383412),(35,'rla@naver.com','대구광역시 중구 태평로 117 (태평로2가)','',2,'14:00:00','11:00:00',115147,'유니온관광호텔',' 코로나 방역을 항상 실시하고 있습니다','13.jpeg','',NULL,35.8761537841792,128.590739541564),(36,'rh@naver.com','대구광역시 중구 국채보상로 611 (문화동)','',1,'14:00:00','11:00:00',114207,'노보텔 앰배서더 대구','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','14.jpeg','',NULL,35.8709617047047,128.598120429496),(37,'qkr@naver.com','대구광역시 중구 동성로1길 15 (동성로3가)','',2,'14:00:00','11:00:00',113267,'토요코인 대구동성로','  호텔 사이트를 참조해주세요 :) \r\n\r\n식당에 쥐가 나와서 식당 폐쇄 했습니다','15.jpeg','',NULL,35.8670220878068,128.59465812643),(38,'rla@naver.com','대구광역시 동구 율암로 156-15, 아마레 호텔 (상매동)','',4,'14:00:00','11:00:00',112327,'아마레호텔',' 코로나 방역을 항상 실시하고 있습니다','16.jpeg','',NULL,35.8886534528523,128.706235287037),(39,'dl@naver.com','대구광역시 동구 동부로 75 (신천동)',NULL,5,'15:00:00','10:00:00',111387,'황실호텔','','17.jpeg','',NULL,35.8757048653997,128.620781125955),(40,'rh@naver.com','대구광역시 동구 팔공산로185길 47 (용수동)','',2,'14:00:00','11:00:00',110447,'(주)뉴힐사이드 호텔','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','18.jpeg','',NULL,35.9909958142228,128.694026327135),(41,'qkr@naver.com','대구광역시 동구 해동로 119 (입석동)','',3,'14:00:00','11:00:00',109507,'동방호텔','사진은 사진일뿐 속지 마세요','19.jpeg','',NULL,35.8897195329378,128.643209360158),(42,'rla@naver.com','대구광역시 동구 이노밸리로 7 (상매동)','',2,'14:00:00','11:00:00',108567,'앙코르호텔',' 코로나 방역을 항상 실시하고 있습니다','20.jpeg','',NULL,35.8877546607072,128.705806417174),(43,'rh@naver.com','대구광역시 동구 공항로 221 (지저동)','',1,'14:00:00','11:00:00',107627,'호텔에어포트','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208152830304.peg','',NULL,35.8991232347795,128.639275313885),(44,'dl@naver.com','대구광역시 서구 북비산로 360 (비산동)','',2,'14:00:00','11:00:00',106687,'엠파이어관광호텔','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208153136640.peg','',NULL,35.8791350746005,128.572554509651),(45,'qkr@naver.com','대구광역시 남구 이천로 13 (봉덕동)','',2,'14:00:00','11:00:00',105747,'(주) 호텔 더 팔래스','사이트 참조','20201208151936430.peg','',NULL,35.8423201902688,128.597606453435),(46,'qkr@naver.com','대구광역시 북구 유통단지로 80 (산격동)','',4,'14:00:00','11:00:00',104807,'(주)호텔 인터불고 엑스코','조식 가능 사이트 참조','20201208152020809.peg','',NULL,35.9070111993429,128.611298373922),(47,'rh@naver.com','대구광역시 수성구 팔현길 212 (만촌동, 호텔인터불고)','',2,'14:00:00','11:00:00',103867,'호텔인터불고','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208152838688.peg','',NULL,35.8744069928036,128.659674743779),(48,'rla@naver.com','대구광역시 수성구 달구벌대로 2421 (범어동)','',2,'14:00:00','11:00:00',102927,'뉴영남관광호텔',' 어메니티를 구비 했습니다\r\n조식도 물론 준비 되어있습니다.','20201208154918306.peg','',NULL,35.8594453929031,128.627651933021),(49,'qkr@naver.com','대구광역시 수성구 동대구로 27 (두산동)','',7,'14:00:00','11:00:00',101987,'호텔아리아나',' 조식 가능 사이트 참조','20201208152034472.peg','',NULL,35.8327007795546,128.622903190968),(50,'qkr@naver.com','대구광역시 달서구 달구벌대로 1910 (두류동)','',2,'14:00:00','11:00:00',101047,'(주)크리스탈관광호텔',' 조식 가능 사이트 참조','20201208152044601.peg','',NULL,35.8621305787509,128.573716612878),(51,'rh@naver.com','대구광역시 달서구 월배로 446 (송현동)','',3,'14:00:00','11:00:00',100107,'뉴-삼일관광호텔','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208152850577.peg','',NULL,35.8331811908744,128.554248890573),(52,'rla@naver.com','대구광역시 달서구 성서로 413 (이곡동)','',2,'14:00:00','11:00:00',99167,'(주)에이더블유 호텔','  어메니티를 구비 했습니다\r\n조식도 물론 준비 되어있습니다.','20201208154928425.peg','',NULL,35.8544550858295,128.506711894104),(53,'qkr@naver.com','대구광역시 달성군 논공읍 약산덧재길 81','',5,'14:00:00','11:00:00',98227,'(주)파라다이스 온천호텔',' 조식 가능 사이트 참조','20201208152148537.peg','',NULL,35.7428354687475,128.427251242461),(54,'qkr@naver.com','강원도 강릉시 교동광장로100번길 8 (교동)','',2,'14:00:00','11:00:00',97287,'THE HONG C HOTEL Gangneung',' 조식 가능 사이트 참조','2020120815224312.peg','',NULL,37.7654189448501,128.876333302778),(55,'rla@naver.com','강원도 강릉시 해안로406번길 13-6 (강문동)','',3,'14:00:00','11:00:00',96347,'경포비치호텔','   어메니티를 구비 했습니다조식도 물론 준비 되어있습니다.','20201208163424640.peg','',NULL,37.7992417608008,128.913296221816),(56,'rh@naver.com','강원도 강릉시 강동면 헌화로 950-39','',2,'14:00:00','11:00:00',95407,'썬크루즈 호텔','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208152931.peg','',NULL,37.6840792898342,129.041889085912),(57,'qkr@naver.com','강원도 강릉시 주문진읍 해안로 2070','',2,'14:00:00','11:00:00',94467,'주문진리조트',' 조식 가능 사이트 참조','20201208152214504.peg','',NULL,37.9088247623291,128.819932038186),(58,'rla@naver.com','강원도 강릉시 옥계면 헌화로 455-34','',3,'14:00:00','11:00:00',93527,'Hotel Tops10','  어메니티를 구비 했습니다\r\n조식도 물론 준비 되어있습니다.','20201208154947224.peg','',NULL,37.6546801839167,129.052901746545),(59,'qkr@naver.com','강원도 강릉시 금성로 62 (성내동, 빈폴타워)','',2,'14:00:00','11:00:00',92587,'강릉관광호텔',' 조식 가능 사이트 참조','20201208152223489.peg','',NULL,37.7518023174169,128.894612978069),(60,'rh@naver.com','강원도 강릉시 해안로406번길 2 (강문동)','',3,'14:00:00','11:00:00',91647,'씨마크호텔','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208152911336.peg','',NULL,37.7972098502599,128.915053907848),(61,'qkr@naver.com','강원도 강릉시 강동면 율곡로 1441','',2,'14:00:00','11:00:00',90707,'하슬라아트월드',' 조식 가능 사이트 참조','20201208152234609.peg','',NULL,37.7054682673374,129.007826158443),(62,'qkr@naver.com','강원도 강릉시 율곡로 2899-1(교동)','',2,'14:00:00','11:00:00',89767,'게스트하우스 안도',' 조식 가능 사이트 참조','20201208152245313.peg','',NULL,37.7617782400611,128.893212298607),(63,'rla@naver.com','강원도 속초시 동해대로 3964 (조양동)','',4,'14:00:00','11:00:00',88827,'(주)현대스카이리조트','  어메니티를 구비 했습니다\r\n조식도 물론 준비 되어있습니다.','20201208154958255.peg','',NULL,38.1887976593727,128.600698832885),(64,'rh@naver.com','강원도 속초시 해오름로 151 (조양동)','',2,'14:00:00','11:00:00',87887,'더 티(the T)','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208152922912.peg','',NULL,38.1878418285485,128.60436673576),(65,'dl@naver.com','강원도 속초시 청초호반로 107 (조양동)','',5,'14:00:00','11:00:00',86947,'브루클린호텔','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208153144576.peg','',NULL,38.1901685487094,128.582536219493),(66,'qkr@naver.com','강원도 속초시 관광로408번길 14 (노학동)','',2,'14:00:00','11:00:00',86007,'설악파인리조트 휴양콘도미니엄',' 조식 가능 사이트 참조','20201208152256777.peg','',NULL,38.1955206947459,128.53907019371),(67,'qkr@naver.com','강원도 속초시 설악산로 1042 (설악동)','',6,'14:00:00','11:00:00',85067,'(주)설악산관광호텔',' 조식 가능 사이트 참조','2020120815231480.peg','',NULL,38.1739732736591,128.488772997534),(68,'rh@naver.com','강원도 속초시 중앙로 104 (청학동)','',2,'14:00:00','11:00:00',84127,'에스관광호텔','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208152933504.peg','',NULL,38.2014332553377,128.587444152952),(69,'rla@naver.com','강원도 속초시 교동로1길 8 (교동)','',2,'14:00:00','11:00:00',83187,'든마루','  어메니티를 구비 했습니다\r\n조식도 물론 준비 되어있습니다.','20201208155012640.peg','',NULL,38.2001423349425,128.580708985322),(70,'dl@naver.com','강원도 속초시 설악산로 852-15 (설악동)','',3,'14:00:00','11:00:00',82247,'(주)호텔 설악파크','    조식 가능 자세한건 사이트 참조해주세요 조식 가능 자세한건 사이트 참조해주세요','20201208153217793.peg','',NULL,38.1703258096343,128.51375385227),(71,'qkr@naver.com','강원도 속초시 대포항길 186, 롯데리조트속초 (대포동)','',2,'14:00:00','11:00:00',81307,'롯데리조트 속초',' 조식 가능 사이트 참조','20201208152323920.peg','',NULL,38.1806265728925,128.612765091496),(72,'rh@naver.com','강원도 속초시 해오름로 129 (대포동)','',2,'14:00:00','11:00:00',80367,'속초비치호스텔','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208152942904.peg','',NULL,38.1858994138096,128.605400874546),(73,'rla@naver.com','강원도 양양군 강현면 낙산사로 73','',2,'14:00:00','11:00:00',79427,'낙산비치호텔','  어메니티를 구비 했습니다\r\n조식도 물론 준비 되어있습니다.','20201208155022776.peg','',NULL,38.1234368408101,128.630695015703),(74,'dl@naver.com','강원도 양양군 현남면 인구중앙길 99','',3,'14:00:00','11:00:00',78487,'핀스하우스호스텔','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208153226424.peg','',NULL,37.9735565664428,128.758904195417),(75,'qkr@naver.com','강원도 양양군 현남면 동해대로 694, 메종드메르 1동 4층','',2,'14:00:00','11:00:00',77547,'메종드메르',' 조식 가능 사이트 참조','20201208152333529.peg','',NULL,37.9659141882783,128.761989402589),(76,'qkr@naver.com','강원도 양양군 현남면 인구중앙길 79, 2층','',3,'14:00:00','11:00:00',76607,'서프더맨션',' 조식 가능 사이트 참조','20201208152342145.peg','',NULL,37.9715348691155,128.75944108599),(77,'rh@naver.com','강원도 양양군 현남면 북분안길 29','',2,'14:00:00','11:00:00',75667,'파크애비뉴','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','2020120815295524.peg','',NULL,37.9883932534808,128.745236439024),(78,'qkr@naver.com','강원도 양양군 손양면 선사유적로 678','',2,'14:00:00','11:00:00',74727,'쏠비치 리조트 양양',' 조식 가능 사이트 참조','20201208152352968.peg','',NULL,38.0882557295881,128.666210973169),(79,'dl@naver.com','강원도 양양군 강현면 동해대로 3393','',2,'14:00:00','11:00:00',73787,'베니키아 호텔 산과바다 양양','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208153240224.peg','',NULL,38.140429356234,128.613672244812),(80,'qkr@naver.com','강원도 양양군 손양면 선사유적로 678','',2,'14:00:00','11:00:00',72847,'쏠비치 호텔 양양',' 조식 가능 사이트 참조','2020120815245465.peg','',NULL,38.0882557295881,128.666210973169),(81,'rh@naver.com','경상북도 경주시 영불로 223 (진현동)','',2,'14:00:00','11:00:00',71907,'사조리조트 경주휴양콘도미니엄','   조식 가능 자세한건 사이트 참조해주세요','20201208153018745.peg','',NULL,35.7831925001495,129.325724241533),(82,'qkr@naver.com','경상북도 경주시 보문로 404 (신평동)','',2,'14:00:00','11:00:00',70967,'콩코드호텔',' 조식 가능 사이트 참조','2020120815241517.peg','',NULL,35.8455232931369,129.283479083685),(83,'dl@naver.com','경상북도 경주시 보문로 371 (신평동)','',2,'14:00:00','11:00:00',70027,'주식회사 더스타일하우스','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208153252560.peg','',NULL,35.8482434138883,129.281950987814),(84,'rla@naver.com','경상북도 경주시 불국로 61 (구정동)','',2,'14:00:00','11:00:00',69087,'그랜드 호텔 경주','  어메니티를 구비 했습니다\r\n조식도 물론 준비 되어있습니다.','20201208155034144.peg','',NULL,35.782878812504,129.301639660768),(85,'rh@naver.com','경상북도 경주시 보문로 353 (신평동)','',2,'14:00:00','11:00:00',68147,'(주)이랜드파크 한국콘도 경주보문','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','2020120815304544.peg','',NULL,35.849159350583,129.279729580188),(86,'qkr@naver.com','경상북도 경주시 태종로699번길 3, 경주지지관광호텔 (노서동)','',2,'14:00:00','11:00:00',67207,'경주지지관광호텔',' 조식 가능 사이트 참조','20201208152425361.peg','',NULL,35.839059296279,129.204432988558),(87,'rla@naver.com','경상북도 경주시 보문로 182-29 (북군동)','',2,'14:00:00','11:00:00',66267,'(주)이랜드파크 켄싱턴리조트 경주','  어메니티를 구비 했습니다\r\n조식도 물론 준비 되어있습니다.','20201208155046351.peg','',NULL,35.8607162384785,129.268434012728),(88,'qkr@naver.com','경상북도 경주시 보문로 338 (신평동)','',2,'14:00:00','11:00:00',65327,'주식회사 라한호텔(경주)',' 조식 가능 사이트 참조','20201208152434185.peg','',NULL,35.850339865401,129.277202399087),(89,'rh@naver.com','경상북도 경주시 양남면 동남로 1021','',2,'14:00:00','11:00:00',64387,'마우나오션 콘도미니엄','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208153031136.peg','',NULL,35.6865388557973,129.370025161784),(90,'qkr@naver.com','경상북도 경주시 엑스포로 45 (신평동)','',2,'14:00:00','11:00:00',63447,'The-K경주호텔',' 조식 가능 사이트 참조','20201208152445888.peg','',NULL,35.8381778238509,129.290223226233),(91,'dl@naver.com','경상북도 경주시 영불로 248 (진현동)','',2,'14:00:00','11:00:00',62507,'불국사가족호텔','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','2020120815331408.peg','',NULL,35.7838215054134,129.328345063016),(92,'qkr@naver.com','경상북도 경주시 감포읍 감포로 344','',2,'14:00:00','11:00:00',61567,'더-영 호스텔',' 조식 가능 사이트 참조','20201208152456673.peg','',NULL,35.8179600183328,129.51085276157),(93,'rh@naver.com','경상북도 경주시 천북면 천강로 295-60','',2,'14:00:00','11:00:00',60627,'케이호텔','  조식 가능\r\n\r\n 자세한건 사이트 참조해주세요\r\n\r\n','20201208153041393.peg','',NULL,35.9157755317417,129.280225635279),(94,'qkr@naver.com','서울특별시 서초구 강남대로12길 23-4','144',6,'15:00:00','11:00:00',1200000,'하이하이텔',' 좋은 숙소입니다~','20201208172033147.peg','20201208172033147.detail.peg',NULL,NULL,NULL);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userinfo`
--

DROP TABLE IF EXISTS `userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userinfo` (
  `userid` varchar(45) NOT NULL,
  `userpw` varchar(45) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `useraddress` varchar(45) DEFAULT NULL,
  `usertel` varchar(45) DEFAULT NULL,
  `userinsertdate` date DEFAULT NULL,
  `userstate` varchar(45) DEFAULT NULL,
  `userdeletedate` date DEFAULT NULL,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `userid_UNIQUE` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userinfo`
--

LOCK TABLES `userinfo` WRITE;
/*!40000 ALTER TABLE `userinfo` DISABLE KEYS */;
INSERT INTO `userinfo` VALUES ('123@naver.com','Killer-081','고종찬','서울특별시 서초구 강남대로101길 23','010-5445-1111','2020-12-08','회원',NULL),('1@1.com','1','고종찬','서울특별시 서초구 동광로33길 15','010-0909-1111','2020-12-05','회원',NULL),('admin','admin',NULL,NULL,NULL,NULL,'탈퇴','2020-12-08'),('admin@admin.com','admin',NULL,NULL,NULL,NULL,'관리자',NULL),('chl@naver.com','Killer-081','고종찬','서울특별시 서초구 강남대로8길 39-56','010-9441-9891','2020-12-08','회원',NULL),('dl@naver.com','1234','강후','모름',NULL,NULL,'호스트',NULL),('godol811@naver.com','killer-081','고종찬','서울특별시 강남구 개포로 202','010-5445-1035','2020-12-07','회원',NULL),('parkkyungmi@naver.com','1234','경미','인천','010-1234-5678','2020-11-21','회원',NULL),('qkr@naver.com','111','나야','서울','010','2020-11-02','호스트',NULL),('qqq@naver.com','111111','박경미','서울특별시 서초구 강남대로12길 23-4','010-2223-7545','2020-12-08','회원',NULL),('rh@naver.com','1234','종찬','제주','010-5445-1035','2020-08-11','호스트',NULL),('rla@naver.com','1234','보람','하남','010-4512-5656',NULL,'호스트',NULL);
/*!40000 ALTER TABLE `userinfo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-09 10:26:08
