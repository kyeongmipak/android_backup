
# FullCalendar ScrollGrid Plugin

Tabular data chunked into scrollable panes

[View the docs &raquo;](https://fullcalendar.io/docs/scheduler)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar-scheduler)
