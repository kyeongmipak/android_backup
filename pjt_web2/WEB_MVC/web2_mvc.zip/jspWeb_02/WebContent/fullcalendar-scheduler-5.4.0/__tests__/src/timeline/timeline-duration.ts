describe('timeline duration', () => {
})
