export const OPTION_REFINERS = {
  schedulerLicenseKey: String,
}
