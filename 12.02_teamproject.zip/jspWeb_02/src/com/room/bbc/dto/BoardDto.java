package com.room.bbc.dto;

public class BoardDto {

}
