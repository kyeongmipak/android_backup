package com.room.bbc.dto;

public class UserDto {

}
