package com.room.bbc.dto;

public class RoomListDto {

}
