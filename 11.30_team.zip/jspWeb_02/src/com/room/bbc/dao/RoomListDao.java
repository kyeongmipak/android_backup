package com.room.bbc.dao;

public class RoomListDao {

}
