package com.jsplec.base;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sun.security.util.DisabledAlgorithmConstraints;

/**
 * Servlet implementation class writePost_01S
 */
@WebServlet("/writePost_01S")
public class writePost_01S extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public writePost_01S() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		request.setCharacterEncoding("utf-8");
		
		String name = request.getParameter("name");
		String title = request.getParameter("title");
		String text = request.getParameter("text");
		
		response.setContentType("text/html;charset = utf-8");
		
		request.setAttribute("name", name);
		request.setAttribute("title", title);
		request.setAttribute("text", text);
		
		RequestDispatcher rd = request.getRequestDispatcher("writePost_02.jsp");
		rd.forward(request, response);
		
	}

}
