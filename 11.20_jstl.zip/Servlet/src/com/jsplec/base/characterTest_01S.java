package com.jsplec.base;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class characterTest_01S
 */
@WebServlet("/characterTest_01S")
public class characterTest_01S extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public characterTest_01S() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		request.setCharacterEncoding("utf-8");
		
		String name = request.getParameter("name");
		String color = request.getParameter("color");
		String animal = request.getParameter("animal");
		String[] food = request.getParameterValues("food");
		String selectFood = "";
		
		// if 사용하여 다중 선택 출력
//		String selectFood =food[0];
//		
//		if(food.length == 1) {
//			selectFood = food[0];
//		}else {
//			for (int i = 1; i < food.length; i++) {
//				selectFood += "과 ";
//				selectFood += food[i];
//			}
//		}
		 
		for (int i = 0; i < food.length-1; i++) {
			selectFood = selectFood +  food[i] + "과 " ;
		}
			selectFood = selectFood + food[food.length-1];
		
		response.setContentType("text/html;charset = utf-8");
		
	
		PrintWriter writer = response.getWriter();
		
		writer.println("<html>");
		writer.println("<head>");
		writer.println("</head>");
		writer.println("<body>");
		writer.println(name + "님의 성격 테스트 결과<br>"+ color +"을 좋아하는 당신은 " + animal +" 그리고 " + selectFood + "을 좋아하는 성격입니다.<br>");
		writer.println("<br> ------------------ <br> 저장되었습니다!");
		writer.println("</body>");
		writer.println("</html>");
		
	
		
		
	}

}
