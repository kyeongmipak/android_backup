package com.jsplec.base;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class userinfoInsert_01S
 */
@WebServlet("/userinfoInsert_01S")
public class userinfoInsert_01S extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public userinfoInsert_01S() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		
		String name = request.getParameter("name");
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String gender = request.getParameter("gender");
		String mailget1 = request.getParameter("mailget1");
		String mailget2 = request.getParameter("mailget2");
		String mailget3 = request.getParameter("mailget3");
		String operation = request.getParameter("operation");
		
		if(mailget1 == null) {
			mailget1 = "받지않음";
		}
		
		if(mailget2 == null) {
			mailget2 = "받지않음";
		}
		
		if(mailget3 == null) {
			mailget3 = "받지않음";
		}
		
		response.setContentType("text/html;charset = utf-8");
		
	
		PrintWriter writer = response.getWriter();
		
		writer.println("<html>");
		writer.println("<head>");
		writer.println("</head>");
		writer.println("<title>개인정보 입력 - 결과화면</title>");
		writer.println("<body>");
		writer.println("이름 : " + name + " <br> 아이디 : " + id +"<br> 패스워드 : " + pw +" <br>");
		writer.println("공지메일 : "+mailget1 + "<br> 광고메일 : " + mailget2 + " <br> 배송 확인메일 : "+mailget3 +" <br>");
		writer.println("직업 : " + operation +  " <br> ------------------ <br> 저장되었습니다!");
		writer.println("</body>");
		writer.println("</html>");
		
		
	}

}
