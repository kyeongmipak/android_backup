package com.jsplec.base;

public class Bean_01 {
	// field
	private String name;
	private int value;
	
	
	// constructor
	public Bean_01() {
		// TODO Auto-generated constructor stub
	}


	// method
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getValue() {
		return value;
	}


	public void setValue(int value) {
		this.value = value;
	}
	
	
}
